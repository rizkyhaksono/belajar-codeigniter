<html>
    <head>
        <title>
            Tambah Mahasiswa
        </title>
        <link rel="stylesheet" href="assets/style.css" type="text/css">
    </head>
    <body>

        <header>
            <h1>Kemahasiswaan Poltek</h1>
            <nav>
                <a href="index.php">Home</a>
            </nav>
        </header>

        <article>
            <p>Detail Mahasiswa</p>
            <br/>

            <h1>Elon Musk</h1>

            <div class="image-wrapper-detail">
                <img src="foto/elon.jpg">
            </div>

            <div>
                <p>
                    NIM: 42525001
                </p>
                <p>
                    Nama: Elon Musk
                </p>
                <p>
                    Alamat: 42525001
                </p>
            </div>

        </article>

        <footer class="article-meta">
            Copyright - All Right Reserved
        </footer>

    </body>
</html>